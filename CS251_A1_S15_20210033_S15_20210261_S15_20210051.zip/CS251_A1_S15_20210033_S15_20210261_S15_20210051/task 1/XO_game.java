/* 
 * software engineering
 * assignment 1 - task 1
 * Tic Tac Toe Game
 * made by : Ahmed Mohamed Taha : 20210033
 *           adham tarek : 20210051
 *           omar ayman : 20210261
 * last update : 12/5/2021
 */

import java.util.Scanner;
import java.io.*;
import java.util.concurrent.TimeUnit;
import java.lang.Thread;

class Player{
    private String name;
    private char symbol;
    public Player(String name, char symbol){
        this.name = name;
        this.symbol = symbol;
    }

    public String getName(){
        return name;
    }
    public char getSymbol(){
        return symbol;
    }
}


class Board{
    private final int SIZE = 3;
    private char[][] board = new char[SIZE][SIZE];
    public Board(){
        for(int i = 0; i < SIZE; i++){
            for(int j = 0; j < SIZE; j++){
                board[i][j] = ' ';
            }
        }
    }

    // get move from player
    public void getMove(Player player, Scanner in){
        System.out.println(player.getName() + "'s turn");
        int row, col;
        
        // check if the move is valid
        boolean first = true;
        do{
            if(!first)
            System.out.println("Invalid move, try again");
            else
                first = false;

            System.out.print("Enter row number: ");
            row = in.nextInt();
            System.out.print("Enter column number: ");
            col = in.nextInt();
        }while(row < 1 || row > 3 || col < 1 || col > 3 || board[row - 1][col - 1] != ' ');
        board[row - 1][col - 1] = player.getSymbol();
    }

    // display the board
    public void display(){
        System.out.println("-------");
        for(int i = 0; i < SIZE; i++){
            System.out.print("|");
            for(int j = 0; j < SIZE; j++){
                System.out.print(board[i][j] + "|");
            }
            System.out.println();
            System.out.print("-------");
            System.out.println();
        }
        System.out.println();
    }

    // check if there is a winner
    public boolean checkWin(){
        // check rows
        for(int i = 0; i < SIZE; i++){
            if(board[i][0] != ' ' && board[i][0] == board[i][1] && board[i][1] == board[i][2]){
                return true;
            }
        }
        // check columns
        for(int i = 0; i < SIZE; i++){
            if(board[0][i] != ' ' && board[0][i] == board[1][i] && board[1][i] == board[2][i]){
                return true;
            }
        }
        // check diagonals
        if(board[0][0] != ' ' && board[0][0] == board[1][1] && board[1][1] == board[2][2]){
            return true;
        }
        if(board[0][2] != ' ' && board[0][2] == board[1][1] && board[1][1] == board[2][0]){
            return true;
        }
        return false;
    }
    
    // check if the board is full to return draw
    public boolean checkDraw(){
        for(int i = 0; i < SIZE; i++){
            for(int j = 0; j < SIZE; j++){
                if(board[i][j] == ' '){
                    return false;
                }
            }
        }
        return true;
    }
}



// ******************************************************************** GAME CLASS ********************************************************************
class Game{
    private Player player[] = new Player[2];
    private Board board;
    int turn;

    public Game(){
        // create board
        board = new Board();
        turn = 0;
    }
    private void clearScreen(){
        System.out.print("\033[H\033[2J");  
        System.out.flush();  
    }

    private void Delay(){
        try{
            // Delay for 3 seonds
            TimeUnit.SECONDS.sleep(3);   
        }
        catch(InterruptedException ex){
            ex.printStackTrace();
        }
    }

    public void start(){
        Scanner sc = new Scanner(System.in);
        String name;

        // get first player name
        System.out.print("Enter name of player 1 : ");
        name = sc.nextLine();
        // setup player 1
        System.out.println("Hi " + name + " your symbol is 'X'.");
        player[0] = new Player(name, 'X');

        Delay();

        // get second player name
        System.out.print("Enter name of player 2 : ");
        name = sc.nextLine();
        // setup player 2
        System.out.println("Hi " + name + " your symbol is 'O'.");
        player[1] = new Player(name, 'O');

        System.out.print("initilizing game...");
        Delay();

        // clear screen
        clearScreen();

        // start game
        board.display();
        while(true){
            // get move from player
            board.getMove(player[turn], sc);

            // display the board
            board.display();

            // check if there is a winner
            if(board.checkWin()){
                System.out.println(player[turn].getName() + " wins");
                break;
            }

            // check if the board is full to return draw
            if(board.checkDraw()){
                System.out.println("Draw");
                break;
            }

            // turn xor 1 to switch between players from 0 to 1 and vice versa
            // to let turn varaible access the index of player array
            turn^=1;
        }
    }
}

class Main{
    public static void main(String args[]){
        Game game = new Game();
        game.start();
    }
}