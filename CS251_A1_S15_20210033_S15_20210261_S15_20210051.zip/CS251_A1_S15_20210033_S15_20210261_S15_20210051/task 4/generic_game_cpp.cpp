#include <iostream>
#include <string>
#include <vector>

// Base class for all game objects
class GameObject {
public:
    GameObject(std::string name) : name(name) {}
    virtual ~GameObject() {}

    virtual void Update() {}

    std::string GetName() const { return name; }

private:
    std::string name;
};

// Class for the game engine
class GameEngine {
public:
    GameEngine() {}

    void Run() {
        while (true) {
            // Update all game objects
            for (auto obj : gameObjects) {
                obj->Update();
            }
        }
    }

    void AddGameObject(GameObject* obj) {
        gameObjects.push_back(obj);
    }

private:
    std::vector<GameObject*> gameObjects;
};

// Example subclass of GameObject
class Player : public GameObject {
public:
    Player(std::string name) : GameObject(name) {}

    void Update() override {
        std::cout << GetName() << " is jumping!" << std::endl;
    }
};

int main() {
    // Create game engine
    GameEngine engine;

    // Create game objects
    Player* player1 = new Player("Player 1");
    Player* player2 = new Player("Player 2");

    // Add game objects to engine
    engine.AddGameObject(player1);
    engine.AddGameObject(player2);

    // Run the game engine
    engine.Run();

    // Clean up
    delete player1;
    delete player2;

    return 0;
}