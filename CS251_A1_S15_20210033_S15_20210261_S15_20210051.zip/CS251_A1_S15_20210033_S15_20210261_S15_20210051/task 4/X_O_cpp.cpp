#include <iostream>
using namespace std;

const int ROWS = 3;
const int COLUMNS = 3;

class TicTacToe {
    private:
        char board[ROWS][COLUMNS];
        char current_player;

    public:
        TicTacToe() {
            initialize_board();
            current_player = 'X';
        }

        void play() {
            int row, column;

            while(!is_game_over()) {
                display_board();
                cout << "Player " << current_player << ", enter a row (1-3): ";
                cin >> row;
                cout << "Player " << current_player << ", enter a column (1-3): ";
                cin >> column;

                if(place_piece(row-1, column-1)) {
                    if(current_player == 'X') {
                        current_player = 'O';
                    } else {
                        current_player = 'X';
                    }
                } else {
                    cout << "Invalid move. Please try again." << endl;
                }
            }

            display_board();
            display_winner();
        }

    private:
        void initialize_board() {
            for(int i=0; i<ROWS; i++) {
                for(int j=0; j<COLUMNS; j++) {
                    board[i][j] = '-';
                }
            }
        }

        bool place_piece(int row, int column) {
            if(row < 0 || row >= ROWS || column < 0 || column >= COLUMNS) {
                return false;
            }

            if(board[row][column] != '-') {
                return false;
            }

            board[row][column] = current_player;
            return true;
        }

        bool is_game_over() {
            if(check_winner() != '-') {
                return true;
            }

            for(int i=0; i<ROWS; i++) {
                for(int j=0; j<COLUMNS; j++) {
                    if(board[i][j] == '-') {
                        return false;
                    }
                }
            }

            return true;
        }

        char check_winner() {
            // Check rows
            for(int i=0; i<ROWS; i++) {
                if(board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != '-') {
                    return board[i][0];
                }
            }

            // Check columns
            for(int j=0; j<COLUMNS; j++) {
                if(board[0][j] == board[1][j] && board[1][j] == board[2][j] && board[0][j] != '-') {
                    return board[0][j];
                }
            }

            // Check diagonals
            if(board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != '-') {
                return board[0][0];
            }

            if(board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != '-') {
                return board[0][2];
            }

            return '-';
        }

        void display_board() {
            cout << "  1 2 3" << endl;
            for(int i=0; i<ROWS; i++) {
                cout << i+1 << " ";
                for(int j=0; j<COLUMNS; j++) {
                    cout << board[i][j] << " ";
                }
                cout << endl;
            }
        }
        void display_winner() {
            char winner = check_winner();

            if(winner == '-') {
                cout << "It's a tie!" << endl;
            } else {
                cout << "Congratulations, player " << winner << " wins!" << endl;
            }
        }
};

int main() {
    TicTacToe game;
    game.play();

    return 0;
}