class TicTacToe:
    def __init__(self):
        self.board = [['-' for _ in range(3)] for _ in range(3)]
        self.current_player = 'X'

    def play(self):
        while not self.is_game_over():
            self.display_board()
            row, column = self.get_move()
            if self.place_piece(row, column):
                if self.current_player == 'X':
                    self.current_player = 'O'
                else:
                    self.current_player = 'X'
            else:
                print("Invalid move. Please try again.")

        self.display_board()
        self.display_winner()

    def get_move(self):
        try:
            row = int(input(f"Player {self.current_player}, enter a row (1-3): ")) - 1
            column = int(input(f"Player {self.current_player}, enter a column (1-3): ")) - 1
            return row, column
        except ValueError:
            print("Invalid input. Please try again.")
            return self.get_move()

    def place_piece(self, row, column):
        if row < 0 or row >= 3 or column < 0 or column >= 3:
            return False

        if self.board[row][column] != '-':
            return False

        self.board[row][column] = self.current_player
        return True

    def is_game_over(self):
        if self.check_winner() != '-':
            return True

        for row in self.board:
            for piece in row:
                if piece == '-':
                    return False

        return True

    def check_winner(self):
        # Check rows
        for row in self.board:
            if row[0] == row[1] == row[2] and row[0] != '-':
                return row[0]

        # Check columns
        for i in range(3):
            if self.board[0][i] == self.board[1][i] == self.board[2][i] and self.board[0][i] != '-':
                return self.board[0][i]

        # Check diagonals
        if self.board[0][0] == self.board[1][1] == self.board[2][2] and self.board[0][0] != '-':
            return self.board[0][0]

        if self.board[0][2] == self.board[1][1] == self.board[2][0] and self.board[0][2] != '-':
            return self.board[0][2]

        return '-'

    def display_board(self):
        print("  1 2 3")
        for i, row in enumerate(self.board):
            print(f"{i+1} {' '.join(row)}")

    def display_winner(self):
        winner = self.check_winner()
        if winner == '-':
            print("It's a tie!")
        else:
            print(f"Congratulations, player {winner} wins!")
            
def main():
    # create a new game
    game = TicTacToe()

    # play the game
    game.play()

if __name__ == '__main__':
    main()