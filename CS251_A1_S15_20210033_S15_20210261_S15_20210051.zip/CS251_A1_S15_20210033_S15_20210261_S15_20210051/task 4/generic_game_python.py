class GameHeader:
    def __init__(self, title, author, version):
        self.title = title
        self.author = author
        self.version = version

class Player:
    def __init__(self, name, score=0):
        self.name = name
        self.score = score

    def increase_score(self, points):
        self.score += points

class HighScores:
    def __init__(self, scores=[]):
        self.scores = scores

    def add_score(self, player):
        self.scores.append(player)

    def get_high_scores(self):
        sorted_scores = sorted(self.scores, key=lambda player: player.score, reverse=True)
        return sorted_scores[:10]